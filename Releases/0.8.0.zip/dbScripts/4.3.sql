﻿DROP TABLE UploadEntries
